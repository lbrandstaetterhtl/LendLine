# Lint-, Format- und TypeScript-Einstellungen

Stand: 24.09.2026. Stammt aus einem TypeScript-Monorepo mit Node-Backend (Express, ESM) und
React-19-Frontend (Vite). Alles ist streng eingestellt: fast alle Regeln stehen auf `error`, das
Backend lintet zusätzlich mit `--max-warnings 0`.

## Werkzeuge

| Zweck                     | Werkzeug                                  | Version (siehe `package-snippets.json`) |
| ------------------------- | ----------------------------------------- | --------------------------------------- |
| Linting (statt ESLint)    | [oxlint](https://oxc.rs)                  | ^1.81                                   |
| Typbasierte Regeln        | oxlint `--type-aware` + `oxlint-tsgolint` | ^7.0                                    |
| Formatierung Code         | oxfmt (Prettier-kompatibel)               | ^0.68                                   |
| Formatierung MD/JSON/YAML | Prettier                                  | ^3.9                                    |
| Typprüfung                | TypeScript                                | ^7.0                                    |
| Toter Code                | knip                                      | ^6.36                                   |
| Pre-Commit                | husky + lint-staged                       | ^9 / ^17                                |

Es gibt **keine ESLint-Konfiguration**: oxlint ersetzt ESLint vollständig. Die Regeln mit Präfix
`eslint(...)`, `typescript/…`, `unicorn/…`, `react/…`, `jsx-a11y/…`, `vitest/…` usw. stehen alle in
den beiden `.oxlintrc.json`.

**Eine Datei, ein Formatierer:** oxfmt formatiert nur Code (`.ts/.tsx/.js/.mjs/.cjs`), Prettier nur
Markdown/JSON/YAML. Deshalb ignoriert `.oxfmtrc.json` alle `*.json`, `*.md`, `*.yml`.

## Inhalt

```
backend/   .oxlintrc.json  tsconfig*.json  knip.json      Node/Express-Backend
frontend/  .oxlintrc.json  .oxfmtrc.json  tsconfig.json  knip.json   React-Frontend
root/      .oxfmtrc.json   .prettierignore  .husky/pre-commit        Repo-Wurzel
package-snippets.json   Versionen, npm-Skripte und lint-staged-Konfiguration je Paket
```

Das Backend nutzt die `.oxfmtrc.json` aus der Wurzel. Das Frontend hat eine eigene, zusätzlich mit
React-Import-Gruppe und Tailwind-Klassensortierung.

## Einrichten

1. Versionen aus `package-snippets.json` als devDependencies übernehmen
   (`npm i -D oxlint oxlint-tsgolint oxfmt typescript knip`).
2. Konfigurationsdateien an die entsprechenden Stellen kopieren.
3. Skripte aus `package-snippets.json` übernehmen. Die wichtigsten:
   - `lint`: `oxlint --max-warnings 0 -c .oxlintrc.json --tsconfig tsconfig.json src/`
   - `lint:types`: dasselbe mit `--type-aware --report-unused-disable-directives` (braucht
     `oxlint-tsgolint`; hier leben die teuren, typbasierten Regeln wie `no-floating-promises`,
     `no-unnecessary-condition`, `switch-exhaustiveness-check`)
   - `format` / `format:fix`: `oxfmt --check .` / `oxfmt .`
   - `typecheck`: `tsc --noEmit`
4. Optional: husky + lint-staged für den Pre-Commit-Hook (`root/.husky/pre-commit`). Der Hook ruft
   zusätzlich `gitleaks` auf, falls installiert — kann weg, wenn nicht gewünscht.

## Was an die Projektstruktur angepasst werden muss

Diese Stellen sind projektspezifisch und sollten angepasst oder entfernt werden:

- **`backend/.oxlintrc.json`**
  - `overrides` für `src/services/scanner/cmpModules/**` (drei Regeln aus, weil dort untrusted
    Browser-Daten geparst werden) — Pfad existiert bei euch nicht.
  - `jsdoc/check-tag-names` → `definedTags`: eigene JSDoc-Tags (`documented`, `tested`, …).
  - `ignorePatterns` enthält `scripts/**` und `**/*.js|mjs` — nach Bedarf.
- **`frontend/.oxlintrc.json`**
  - `react-hooks/exhaustive-deps` → `additionalHooks: "(useAbortableEffect)"`: eigener Hook-Name.
  - `import/no-unassigned-import` → `allow` enthält `**/i18n`.
  - `settings.jsx-a11y.components` mappt `Link`/`Button` auf `a`/`button`.
- **`frontend/.oxfmtrc.json`**: `sortTailwindcss.stylesheet` zeigt auf `./src/index.css`.
- **`.oxfmtrc.json`**: `ignorePatterns` mit `migrations/**` und `**/scripts/attic/**`.
- **`tsconfig*.json`**: `paths` für `@shared/*` (geteilte Typen zwischen Frontend und Backend).
  `ignoreDeprecations: "6.0"` im Backend ist für TypeScript 7 nötig.
- **`knip.json`**: `ignoreDependencies`/`ignoreBinaries` sind projektspezifisch.

## TypeScript-Strenge (Kurzfassung)

Beide Seiten: `strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `noImplicitReturns`,
`noFallthroughCasesInSwitch`, `allowUnreachableCode: false`, `verbatimModuleSyntax`,
`erasableSyntaxOnly`, `isolatedModules`. Backend zusätzlich ESM mit `module`/`moduleResolution`
`NodeNext` (relative Importe brauchen `.js`-Endung). `noUnusedLocals/Parameters` sind im Backend nur
im Build-Config (`tsconfig.build.json`) an, damit Tests und Editor nicht darüber stolpern; im
Frontend immer.

## Zwei Fallen aus der Praxis

- oxfmt formatiert JSDoc als Markdown (`jsdoc`-Option): `__tests__` in einem `/** */`-Kommentar wird
  zu `**tests**` und beendet den Kommentar vorzeitig; eingerückte Befehlsbeispiele werden in
  Fließtext gezogen und großgeschrieben. Pfade in Backticks setzen, Befehle in ` ```sh `-Blöcke.
- oxfmts Import-Sortierung zieht `import type` nach vorn — steht der Datei-Kopfkommentar über einem
  Wert-Import, rutscht er darunter. Typ-Importe direkt unter den Kopfkommentar schreiben.
